package com.example.yeet;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.TableLayout;
import android.widget.TableRow;

import com.google.android.material.tabs.TabLayout;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        //TableLayout tableLayout = findViewById(R.id.tableLayout);
        //tableLayout.removeAllViews();

        Adapter adapter = new Adapter(generate());
        RecyclerView recyclerView = findViewById(R.id.rv_table);
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new GridLayoutManager(this, 2));
        recyclerView.setAdapter(adapter);

    }

    private List<Model> generate(){
        List<Model> modelList = new ArrayList<>();

        ArrayList<ImageButton> rows = new ArrayList<>();
        rows.add(findViewById(R.id.star1));

       for(int i = 0; i < 100; i++){
          modelList.add(new Model(rows.get(i)));

        }
        return modelList;
    }
}