package com.example.yeet;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

public class Adapter extends RecyclerView.Adapter {

    private List<Model> models = new ArrayList<>();

    public Adapter(List<Model> viewModels) {
        if (viewModels != null) {
            this.models.addAll(viewModels);
        }
    }

    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(viewType, parent, false);
        return new ViewHolder(view);
    }

    public void onBindViewHolder(RecyclerView.ViewHolder holder, int position){
        ((ViewHolder)holder).bindData(models.get(position));

    }

    public int getItemCount(){
        return models.size();
    }

    public int getItemViewType(int position){
        return R.layout.rv_layout;
    }

}
