package com.example.yeet;

import android.view.View;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.TableLayout;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

public class ViewHolder extends RecyclerView.ViewHolder {

    private LinearLayout row;

    public ViewHolder(View itemView){
        super(itemView);
        row = (LinearLayout) itemView.findViewById(R.id.row);

    }

    public void bindData(Model viewModel){
        row.addView(viewModel.getRow());

    }
}

