package com.example.yeet;

import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.TableRow;

public class Model {
    private ImageButton img;

    public  Model (ImageButton img){ setRow(img);
    }

    public ImageButton getRow(){
        return img;
    }

    public void setRow(ImageButton img) {
        this.img = img;
    }

}
